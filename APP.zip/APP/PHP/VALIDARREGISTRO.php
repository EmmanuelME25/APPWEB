<?php
$Nombre = $_POST["nombre"];
$Papellido = $_POST["apellido1"];
$Sapellido = $_POST["apellido2"];
$Correo = $_POST["correo"];
$Contrasena = $_POST["contrasena"];
$Numero = $_POST["telefono"];
$a = 9;

echo $a;
echo $_POST["nombre"];
echo apellido1;
echo apellido2;
echo correo;
echo telefono;
echo contrasena;
?>