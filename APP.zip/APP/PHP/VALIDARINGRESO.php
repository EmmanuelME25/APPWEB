<?PHP
$Nombre = $_POST["nombre"];
$Papellido = $_POST["apellido1"];
$Sapellido = $_POST["apellido2"];
$Correo = $_POST["correo"];
$Contrasena = $_POST["contrasena"];
$Numero = $_POST["telefono"];





?>