<?php


$Titulo = $_POST["titulo"];
$Autor = $_POST["autor"];
$Editorial = $_POST["editorial"];
$Edicion = $_POST["edicion"];
$Estado = $_POST["estado"];



?>